/** @type import("vite").UserConfig */
export default {
}